

<!-- Form Mixin-->
<!-- Input Mixin-->
<!-- Button Mixin-->
<!-- Pen Title-->
<div class="pen-title">
  <h1>Iniciar Sesion</h1>
</div>
<!-- Form Module-->
<div class="module form-module">
  <div class="toggle">

  </div>
  <div class="form">

    <form>
      <input type="text" placeholder="Usuario"/>
      <input type="password" placeholder="Contraseña"/>
      <button>Login</button>
    </form>
  </div>

  <div class="cta"><a href="#">Forgot your password?</a></div>
</div>
